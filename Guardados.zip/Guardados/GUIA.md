# Guardados — guía de instalación (Nothing Phone 3)

App Android que aparece en el menú "Compartir" de TikTok, YouTube, Reddit, etc.
Guarda el enlace en tu móvil, sin cuentas ni servidores.

## 1. Instalarla en tu móvil

1. En el ordenador, instala **Android Studio** (https://developer.android.com/studio).
2. Descomprime `Guardados.zip` y abre la carpeta con Android Studio (File > Open).
   Espera a que termine la sincronización de Gradle (la primera vez tarda unos minutos y descarga cosas).
3. En el Nothing Phone 3: Ajustes > Acerca del teléfono > pulsa 7 veces en "Número de compilación".
   Luego Ajustes > Sistema > Opciones de desarrollador > activa **Depuración por USB**.
4. Conecta el móvil por USB, acepta el aviso de depuración y pulsa el botón verde **Run** (▶) en Android Studio.
   La app queda instalada.

## 2. Cómo se usa

- **Guardar:** en TikTok, YouTube o Reddit pulsa Compartir y elige **Guardados**. Sale un aviso y vuelves a lo que estabas viendo.
- **Importar los antiguos:** botón **Importar** y eliges el archivo exportado de cada plataforma:
  - TikTok: Ajustes > Cuenta > Descargar tus datos (formato TXT o JSON). Cuando esté listo, descarga el archivo y elige el `.txt`.
  - Reddit: pide tus datos en https://www.reddit.com/settings/data-request y usa el CSV de guardados (`saved_posts.csv`).
  - YouTube: Google Takeout (https://takeout.google.com) > YouTube > listas de reproducción, y elige el CSV de "Ver más tarde" o de la lista que quieras.
  - También sirve cualquier archivo de texto con enlaces.
- **A Obsidian:** botón **A Obsidian** y eliges una carpeta dentro de tu vault (por ejemplo `Documentos/MiVault/Guardados`). Crea una nota `.md` por enlace, solo con los nuevos desde la última vez.
- **Copiar para Claude:** copia todo agrupado por plataforma. Lo pegas en Claude y te hace el resumen.
- Tocar un guardado lo abre. Mantener pulsado lo borra.

## Límites a tener en cuenta

- Los títulos se leen de la propia web. TikTok e Instagram a veces no los dan, y entonces verás el enlace tal cual.
- Si Obsidian no ve la carpeta, elige una dentro de Documentos, no en la raíz ni en Android/data.
