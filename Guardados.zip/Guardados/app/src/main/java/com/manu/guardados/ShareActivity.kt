package com.manu.guardados

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Recibe lo que compartes desde cualquier app, lo guarda y se cierra al instante. */
class ShareActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val url = Util.extractUrls(text).firstOrNull()
        if (url == null) {
            Toast.makeText(this, "No he encontrado ningún enlace", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val store = Store(applicationContext)
        val platform = Util.platformOf(url)
        val hint = text.replace(url, "").trim()
            .ifBlank { intent.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty() }
            .ifBlank { url }

        val id = store.add(url, hint, platform)
        if (id == -1L) {
            Toast.makeText(this, "Ya lo tenías guardado", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Guardado en $platform", Toast.LENGTH_SHORT).show()
            // Intenta mejorar el título en segundo plano
            Thread {
                Util.fetchTitle(url)?.let { store.updateTitle(url, it) }
            }.start()
        }
        finish()
    }
}
