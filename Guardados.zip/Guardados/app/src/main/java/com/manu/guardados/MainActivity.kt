package com.manu.guardados

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var adapter: ItemAdapter
    private var items: List<Item> = emptyList()
    private var fillingTitles = false

    private val reqImport = 1
    private val reqExport = 2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(applicationContext)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left + dp(12), b.top + dp(8), b.right + dp(12), b.bottom + dp(8))
            insets
        }

        val title = TextView(this).apply {
            text = "Guardados"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(title)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        buttons.addView(button("Importar") { pickImportFile() })
        buttons.addView(button("A Obsidian") { pickExportFolder() })
        buttons.addView(button("Copiar para Claude") { copyForClaude() })
        root.addView(buttons)

        search = EditText(this).apply {
            hint = "Buscar…"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = refresh()
            })
        }
        root.addView(search)

        status = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(status)

        adapter = ItemAdapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(items[pos].url)))
                } catch (e: Exception) {
                    toast("No puedo abrir ese enlace")
                }
            }
            setOnItemLongClickListener { _, _, pos, _ ->
                val item = items[pos]
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("¿Borrar este guardado?")
                    .setMessage(item.title)
                    .setPositiveButton("Borrar") { _, _ -> store.delete(item.id); refresh() }
                    .setNegativeButton("Cancelar", null)
                    .show()
                true
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(list)

        setContentView(root)
        refresh()
        fillTitles()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = store.all(search.text.toString())
        adapter.notifyDataSetChanged()
        status.text = "${items.size} guardados"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- Importar ----------

    private fun pickImportFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, reqImport)
    }

    private fun pickExportFolder() {
        if (store.pendingExport().isEmpty()) {
            toast("No hay nada nuevo que exportar")
            return
        }
        toast("Elige la carpeta de tu vault de Obsidian donde guardar las notas")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), reqExport)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            reqImport -> importFrom(uri)
            reqExport -> exportTo(uri)
        }
    }

    private fun importFrom(uri: Uri) {
        status.text = "Importando…"
        Thread {
            val added = try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                Util.extractFromExport(text).count { url ->
                    store.add(url, url, Util.platformOf(url)) != -1L
                }
            } catch (e: Exception) {
                -1
            }
            runOnUiThread {
                refresh()
                if (added < 0) toast("No he podido leer ese archivo")
                else {
                    toast("Importados $added enlaces nuevos")
                    fillTitles()
                }
            }
        }.start()
    }

    /** Busca el título real de los enlaces que solo tienen la URL (de 30 en 30). */
    private fun fillTitles() {
        if (fillingTitles) return
        val pending = store.pendingTitles().take(30)
        if (pending.isEmpty()) return
        fillingTitles = true
        Thread {
            pending.forEachIndexed { n, item ->
                Util.fetchTitle(item.url)?.let { store.updateTitle(item.url, it) }
                if (n % 5 == 4) runOnUiThread { refresh() }
            }
            fillingTitles = false
            runOnUiThread { refresh() }
        }.start()
    }

    // ---------- Exportar ----------

    private fun exportTo(tree: Uri) {
        status.text = "Exportando…"
        Thread {
            var done = 0
            try {
                val parent = DocumentsContract.buildDocumentUriUsingTree(
                    tree, DocumentsContract.getTreeDocumentId(tree)
                )
                for (item in store.pendingExport()) {
                    try {
                        val name = "${Util.date(item.savedAt)} ${Util.slug(item.title)}-${item.id}.md"
                        val doc = DocumentsContract.createDocument(contentResolver, parent, "text/markdown", name)
                            ?: continue
                        contentResolver.openOutputStream(doc)?.use {
                            it.write(Util.markdown(item).toByteArray(Charsets.UTF_8))
                        }
                        store.markExported(item.id)
                        done++
                    } catch (e: Exception) {
                        // seguimos con el siguiente
                    }
                }
            } catch (e: Exception) {
                // se informa abajo con el contador
            }
            runOnUiThread {
                refresh()
                toast(if (done > 0) "Exportadas $done notas a Obsidian" else "No se pudo exportar. Prueba con otra carpeta (por ejemplo dentro de Documentos)")
            }
        }.start()
    }

    private fun copyForClaude() {
        val all = store.all()
        if (all.isEmpty()) {
            toast("Todavía no hay nada guardado")
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Guardados", Util.forClaude(all)))
        toast("Copiados ${all.size} guardados. Pégalos en Claude")
    }

    // ---------- Lista ----------

    private inner class ItemAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val titleView: TextView
            val subView: TextView
            if (convertView is LinearLayout) {
                row = convertView
                titleView = row.getChildAt(0) as TextView
                subView = row.getChildAt(1) as TextView
            } else {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(10), 0, dp(10))
                }
                titleView = TextView(this@MainActivity).apply {
                    textSize = 16f
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                subView = TextView(this@MainActivity).apply { textSize = 12f; alpha = 0.6f }
                row.addView(titleView)
                row.addView(subView)
            }
            val item = items[position]
            titleView.text = item.title
            subView.text = "${item.platform} · ${Util.date(item.savedAt)}"
            return row
        }
    }
}
