package com.manu.guardados

import android.net.Uri
import android.text.Html
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Util {

    private val urlRegex = Regex("""https?://[^\s"'<>\\),;]+""")

    // Lista de vídeos exportada por Google Takeout: "ID_VIDEO,2024-01-01T10:00:00+00:00"
    private val youtubeIdRegex = Regex("""(?m)^([A-Za-z0-9_-]{11}),\d{4}-\d{2}-\d{2}T""")

    fun extractUrls(text: String): List<String> =
        urlRegex.findAll(text)
            .map { it.value.trimEnd('.', ']', '}') }
            .distinct()
            .toList()

    /** Enlaces + IDs de YouTube de un archivo exportado. Solo plataformas conocidas. */
    fun extractFromExport(text: String): List<String> {
        val urls = extractUrls(text).filter { platformOf(it) != "Web" }
        val yt = youtubeIdRegex.findAll(text).map { "https://www.youtube.com/watch?v=${it.groupValues[1]}" }
        return (urls + yt).distinct()
    }

    fun platformOf(url: String): String {
        val host = Uri.parse(url).host?.lowercase() ?: return "Web"
        return when {
            "tiktok" in host -> "TikTok"
            "youtube" in host || host == "youtu.be" -> "YouTube"
            "reddit" in host || host == "redd.it" -> "Reddit"
            "instagram" in host -> "Instagram"
            host == "x.com" || "twitter" in host -> "X"
            else -> "Web"
        }
    }

    /** Intenta leer el título de la página. Devuelve null si no se puede. */
    fun fetchTitle(url: String): String? = try {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000
            readTimeout = 6000
            instanceFollowRedirects = true
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36"
            )
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
        }
        val buf = ByteArray(300_000)
        var n = 0
        c.inputStream.use { s ->
            while (n < buf.size) {
                val r = s.read(buf, n, buf.size - n)
                if (r < 0) break
                n += r
            }
        }
        val html = String(buf, 0, n, Charsets.UTF_8)
        val raw = Regex("""<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
            ?: Regex("""<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']""", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.get(1)
            ?: Regex("""<title[^>]*>(.*?)</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(html)?.groupValues?.get(1)
        raw?.let {
            Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString()
                .replace(Regex("\\s+"), " ")
                .removeSuffix(" - YouTube")
                .trim()
                .take(200)
        }?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun date(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

    fun slug(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .take(60)
            .ifBlank { "enlace" }

    /** Una nota de Obsidian por enlace, con propiedades YAML. */
    fun markdown(i: Item): String = buildString {
        append("---\n")
        append("url: ${i.url}\n")
        append("plataforma: ${i.platform}\n")
        append("guardado: ${date(i.savedAt)}\n")
        append("tags: [guardado, ${i.platform.lowercase()}]\n")
        append("---\n\n")
        append("# ${i.title.replace('\n', ' ')}\n\n")
        append("[Abrir enlace](${i.url})\n")
    }

    /** Todo junto, agrupado por plataforma, listo para pegar en Claude. */
    fun forClaude(items: List<Item>): String = buildString {
        append("# Mis guardados (${items.size})\n\n")
        append("Resume estos enlaces por temas y dime qué merece la pena añadir a mi base de conocimiento.\n\n")
        items.groupBy { it.platform }.forEach { (platform, list) ->
            append("## $platform (${list.size})\n")
            list.forEach { append("- [${it.title.replace('\n', ' ')}](${it.url}) — ${date(it.savedAt)}\n") }
            append("\n")
        }
    }
}
