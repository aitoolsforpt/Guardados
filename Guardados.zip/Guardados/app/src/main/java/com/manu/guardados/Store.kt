package com.manu.guardados

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Item(
    val id: Long,
    val url: String,
    val title: String,
    val platform: String,
    val savedAt: Long
)

class Store(context: Context) : SQLiteOpenHelper(context, "guardados.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "url TEXT NOT NULL UNIQUE, " +
                "title TEXT NOT NULL, " +
                "platform TEXT NOT NULL, " +
                "saved_at INTEGER NOT NULL, " +
                "exported INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    /** Devuelve el id nuevo, o -1 si ese enlace ya estaba guardado. */
    fun add(url: String, title: String, platform: String): Long {
        val cv = ContentValues().apply {
            put("url", url)
            put("title", title)
            put("platform", platform)
            put("saved_at", System.currentTimeMillis())
        }
        return writableDatabase.insertWithOnConflict("items", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun updateTitle(url: String, title: String) {
        val cv = ContentValues().apply { put("title", title) }
        writableDatabase.update("items", cv, "url = ?", arrayOf(url))
    }

    fun delete(id: Long) {
        writableDatabase.delete("items", "id = ?", arrayOf(id.toString()))
    }

    fun markExported(id: Long) {
        val cv = ContentValues().apply { put("exported", 1) }
        writableDatabase.update("items", cv, "id = ?", arrayOf(id.toString()))
    }

    private fun query(where: String?, args: Array<String>?): List<Item> {
        val out = ArrayList<Item>()
        readableDatabase.query(
            "items",
            arrayOf("id", "url", "title", "platform", "saved_at"),
            where, args, null, null, "saved_at DESC"
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Item(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
            }
        }
        return out
    }

    fun all(q: String = ""): List<Item> {
        if (q.isBlank()) return query(null, null)
        val like = "%${q.trim()}%"
        return query("title LIKE ? OR url LIKE ? OR platform LIKE ?", arrayOf(like, like, like))
    }

    /** Elementos cuyo título todavía es la propia URL (no se pudo leer el título). */
    fun pendingTitles(): List<Item> = query("title = url", null)

    /** Elementos que aún no se han exportado a markdown. */
    fun pendingExport(): List<Item> = query("exported = 0", null)
}
